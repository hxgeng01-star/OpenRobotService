import { Fragment, useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { Navbar, Button, Textarea, Toast, Loading, Tag, Popup, Dialog, Form, FormItem } from 'tdesign-mobile-react';
import AppButton from '@/shared/components/AppButton';
import { User, UserCheck, Folder, AlarmClock, Clock, RefreshCw, Building2, Store, Download, FileImage, FileText, FileSpreadsheet, FileCode, FileArchive, Paperclip, Bot } from 'lucide-react';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import ClearableInput from '@/shared/components/ClearableInput';
import TitleEllipsis from '@/shared/components/TitleEllipsis';
import { setupWechatShare, isPcWechat } from '@/shared/utils/wechatJsSdk';
import { WECHAT_CONFIG } from '@/config/wechat';
import { createRequest, getToken, ApiError } from '@/api/client';
import API_CONFIG from '@/config/api';
import { readStored } from '@/stores/authStorage';
import SafeHtml from '@/shared/components/SafeHtml';
import DiscussionPanel from '@/shared/components/DiscussionPanel';
import TicketDynamicsCard from '@/shared/components/TicketDynamicsCard';
import StepNegotiationCard from '@/shared/components/StepNegotiationCard';
import SpecDocCard from '@/shared/components/SpecDocCard';
import { useStepNegotiation } from '@/shared/hooks/useStepNegotiation';
import { useResolveTicket } from '@/shared/hooks/useResolveTicket';
import AttachmentViewer, { type AttachmentViewItem } from '@/shared/components/AttachmentViewer';
import DispatchFold from '@/shared/components/DispatchFold';
import RelationBlock from '@/shared/components/RelationBlock';
import type { BlockedErrorDetail } from '@/api/ticket';
import UserSelect from '@/shared/components/UserSelect';
import type { UserItem } from '@/api/users';
import { useWorkbenchStore } from '@/stores/workbench';
import { useAuthStore } from '@/stores/auth';
import { uploadCommentAttachment, getProxyRelations, type ProxyRelation } from '@/api/ticket';
import ProxyRelationBanner from '@/shared/components/ProxyRelationBanner';
import { TICKET_TYPE_DISPLAY_MAP, STATUS_DISPLAY_MAP, PRIORITY_DISPLAY_MAP, canEditPriority } from '@/shared/constants/ticket';
import { isSameUser } from '@/shared/utils/userIdentity';
import { getDeadlineRange, makeDisabledDate, makeDisabledTime, parseDeadlineString } from '@/shared/utils/deadline';
import { formatDateTime, formatRawDateTime } from '@/shared/utils/url';
import { fetchWithAuth } from '@/api/ai';
import { getProjectMembers } from '@/api/projects';
import type { ProjectMember } from '@/api/projects';
import { dedupeFileNames } from '@/shared/utils/uniqueFileNames';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { appUrlTransform } from '@/shared/utils/markdown';

// 状态文字色（设计稿 statusText 蓝阶：待处理 blue-3 / 处理中·进行中 blue-2 / 已解决 blue-1 / 关闭·取消 muted）
const STATUS_TEXT_COLOR_MAP: Record<string, string> = {
  new: 'var(--blue-3)',
  in_progress: 'var(--blue-2)',
  pending: 'var(--blue-2)',
  paused: 'var(--blue-2)',
  resolved: 'var(--blue-1)',
  closed: 'var(--muted-foreground)',
  canceled: 'var(--muted-foreground)',
  cancelled: 'var(--muted-foreground)',
};

const getStatusTextColor = (status: string): string => {
  const key = (status || '').toLowerCase();
  return STATUS_TEXT_COLOR_MAP[key] || 'var(--muted-foreground)';
};

const formatFileSize = (bytes?: number): string => {
  if (!bytes || bytes <= 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
};

// 文件类型图标（lucide，与设计稿图标体系一致）
const FileTypeIcon = ({ filename, size = 22 }: { filename?: string; size?: number }) => {
  const ext = (filename || '').split('.').pop()?.toLowerCase() || '';
  const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
  const docExts = ['pdf', 'doc', 'docx', 'txt', 'md'];
  const sheetExts = ['xls', 'xlsx', 'csv'];
  const codeExts = ['json', 'js', 'ts', 'py', 'html', 'css'];
  const archiveExts = ['zip', 'rar', '7z', 'tar', 'gz'];
  const props = { size, strokeWidth: 1.8 } as const;
  if (imageExts.includes(ext)) return <FileImage {...props} />;
  if (docExts.includes(ext)) return <FileText {...props} />;
  if (sheetExts.includes(ext)) return <FileSpreadsheet {...props} />;
  if (codeExts.includes(ext)) return <FileCode {...props} />;
  if (archiveExts.includes(ext)) return <FileArchive {...props} />;
  return <Paperclip {...props} />;
};

const isImageFile = (filename?: string): boolean => {
  const ext = (filename || '').split('.').pop()?.toLowerCase() || '';
  return ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'].includes(ext);
};

interface MinioPathInfo { bucket: string; objectKey: string; }

const parseMinioPath = (rawPath: string): MinioPathInfo | null => {
  try {
    const url = new URL(rawPath);
    const parts = decodeURIComponent(url.pathname).replace(/^\//, '').split('/');
    if (parts.length < 2) return null;
    const bucket = parts[0];
    const objectKey = parts.slice(1).join('/');
    if (!bucket || !objectKey) return null;
    return { bucket, objectKey };
  } catch {
    const idx = rawPath.indexOf('://');
    if (idx === -1) return null;
    const pathPart = rawPath.slice(rawPath.indexOf('/', idx + 3));
    const cleaned = decodeURIComponent(pathPart.replace(/^\//, ''));
    const slashIdx = cleaned.indexOf('/');
    if (slashIdx === -1) return null;
    return { bucket: cleaned.slice(0, slashIdx), objectKey: cleaned.slice(slashIdx + 1) };
  }
};

interface Attachment { path: string; size?: number; filename?: string; url?: string; id?: string; }
interface Comment { id: string; content: string; created_by_name?: string; created_by?: string; created_at: string; attachments?: Array<string | { path?: string; filename?: string; size?: number }>; reply_to?: string | number; quoted?: { id: string | number; content: string; created_by_name?: string }; }
interface Ticket {
  id: string; title: string; description: string; status: string; priority: string;
  ticket_type: string; project_name?: string; project_id?: string;
  created_by?: string; created_by_name?: string;
  assigned_to?: string; assigned_to_name?: string;
  reporter_name?: string; assignee_name?: string;
  contact?: string; customer?: string; created_at: string; updated_at: string;
  attachments?: Attachment[]; metadata_info?: Record<string, unknown>; comments?: Comment[];
  // tasks 详情接口 GET /{id} 返回蛇形 deadline_at（见 TicketResponse）
  deadline_at?: string | null;
  // 二次派单感知增强（M3）：未派到指定人时的完整话术（详情页 redispatch.result.tip_detail）
  // 二次派单感知增强：派单理由（为什么派给接单人，仅接单人/管理员可见 → redispatch.result.reasoning）
  redispatch?: { result?: { tip_detail?: string | null; reasoning?: string | null } } | null;
  // 工单阶段性处理（协商节点）：当前节点 ID/名称/结束时间（naive UTC）
  curr_step_id?: number | null;
  curr_step_name?: string | null;
  curr_step_endtime?: string | null;
  // 回合制：最近一次改 step 的操作人侧标识（assigned/creator）与回合数
  step_last_updated_by?: 'assigned' | 'creator' | null;
  step_last_updated_at?: string | null;
  step_negotiation_round?: number;
  step_phase_round?: number;
  step_neg_max_rounds?: number;
  // 当前协商节点是否已协商一致：确认同意 → True；进入新节点 / 协商节点时间 → 重置 False
  curr_step_agreed?: boolean;
  // 升级上报次数：>0 表示已升级，协商回合重置为1且不再受限
  escalate_count?: number;
  // ── 代他人提单（代理提单）：后端下发的关系与视角标记（非参与人为空/False）──
  proxy_relation_status?: 'pending' | 'acknowledged' | 'declined' | null;
  proxy_agent_name?: string | null;
  proxy_principal_name?: string | null;
  is_proxy_agent?: boolean;
  is_principal?: boolean;
}

// 协商阶段模板步骤（GET /{task_id}/steps 返回）
interface StepTemplate {
  id: number;
  step_name: string;
  sequence: number;
}

const generateTempId = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `t_${Date.now()}_${Math.random().toString(36).slice(2)}`;

const AI_NAME = 'U老师';

export default function TaskDetailPage() {
  const { id: detailId } = useParams<{ id: string }>();
  const navigate = useNavigate();
  // 从列表卡片跳进来时的讨论区定位参数（点参与人头像 → focus=discussion[&author=xxx|&commentId=xxx]）
  const [searchParams] = useSearchParams();
  const focusDiscussion = searchParams.get('focus') === 'discussion';
  const focusCommentId = searchParams.get('commentId');
  const focusAuthor = searchParams.get('author');
  const request = createRequest(API_CONFIG.TASKS.BASE_URL, '工单服务');
  const adminRequest = createRequest(API_CONFIG.ADMIN.BASE_URL, '管理服务');

  const { refreshTasks } = useWorkbenchStore();
  const { username, userId, name, hasPermission, isAdmin } = useAuthStore();

  const [detail, setDetail] = useState<Ticket | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  // 二次派单感知增强（M3）：未派到指定人时的完整情商话术（详情页 redispatch.result.tip_detail）
  const [redispatchTipDetail, setRedispatchTipDetail] = useState<string>('');
  // 二次派单感知增强：派单理由（为什么派给接单人；仅接单人/管理员可看到，详情页 redispatch.result.reasoning）
  const [dispatchReason, setDispatchReason] = useState<string>('');
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState<{ title: string; description: string; priority: string; ticket_type: string; curr_step_endtime?: string }>({ title: '', description: '', priority: 'medium', ticket_type: 'problem' });
  // 当前阶段截止时间区间：基准 = 工单创建时间（detail.created_at），而非用户操作时刻
  const editDeadlineRange = getDeadlineRange(editForm.priority, detail?.created_at);
  // 优先级仅在「尚未派单」（待处理/待派单）可修改；已派单及后续状态禁止（置灰不可点）
  const priorityDisabled = !canEditPriority(detail?.status);
  const [escalateUser, setEscalateUser] = useState<UserItem | null>(null);
  const [showEscalatePopup, setShowEscalatePopup] = useState(false);
  const [resumeUser, setResumeUser] = useState<UserItem | null>(null);
  const [showResumePopup, setShowResumePopup] = useState(false);
  const [reassignUser, setReassignUser] = useState<UserItem | null>(null);
  const [showReassignPopup, setShowReassignPopup] = useState(false);
  const [showReturnConfirmPopup, setShowReturnConfirmPopup] = useState(false);
  const [escalateReason, setEscalateReason] = useState('');
  const [returnReason, setReturnReason] = useState('');
  const [reassignReason, setReassignReason] = useState('');
  const [reassignKind, setReassignKind] = useState<'misassign' | 'stage' | 'other' | ''>('');
  // 创建人姓名编辑（仅处理人/管理员可点击设置）
  const [showCreatorNamePopup, setShowCreatorNamePopup] = useState(false);
  const [creatorNameInput, setCreatorNameInput] = useState('');
  const [submittingCreatorName, setSubmittingCreatorName] = useState(false);
  // 当前阶段截止时间直接编辑（拥有 backend:tasks:operate 权限的用户可点击信息项改期）
  // deadlineDraft: undefined=未改动（保存时不提交该字段）；ISO 字符串=新时间；null=清除
  const [showDeadlinePopup, setShowDeadlinePopup] = useState(false);
  const [deadlineDraft, setDeadlineDraft] = useState<string | null | undefined>(undefined);
  // 关联工单阻塞提示（状态变更 422 时传入 RelationBlock 展示）
  const [blockedError, setBlockedError] = useState<BlockedErrorDetail | null>(null);
  const [submittingDeadline, setSubmittingDeadline] = useState(false);
  const [submittingComment, setSubmittingComment] = useState(false);
  const [askingAI, setAskingAI] = useState(false);

  // 结束工单确认弹窗：问题 + AI 解决方式
  const [showResolutionPopup, setShowResolutionPopup] = useState(false);
  const [resolutionText, setResolutionText] = useState('');
  const [resolutionLoading, setResolutionLoading] = useState(false);
  const [resolutionFailed, setResolutionFailed] = useState(false);
  const [resolutionPolling, setResolutionPolling] = useState(false);
  // AI 判定当前无解决方案（仅占位提示，不填入输入框）
  const [resolutionNoSolution, setResolutionNoSolution] = useState(false);
  // 标记是否已"确认完成"成功（成功后关闭弹窗不应清除草稿；取消/遮罩关闭才清除）
  const resolveConfirmedRef = useRef(false);
  // 轮询停止标志：取消/关闭时置 true，让异步轮询循环及时退出（state 无法中断 while 循环）
  const resolvePollStopRef = useRef(false);
  // 确认完成提交中（防重复提交）
  const [resolutionSubmitting, setResolutionSubmitting] = useState(false);

  // U老师 诊断
  const [diagnosing, setDiagnosing] = useState(false);
  const [diagnosisReport, setDiagnosisReport] = useState('');  // raw Markdown
  const [reportVisible, setReportVisible] = useState(false);

  // AI 摘要（后端定时写入评论，前端从评论提取展示）
  const [aiSummary, setAiSummary] = useState('');

  // 公司/部门审核
  const [approving, setApproving] = useState(false);
  const [showAdjustPopup, setShowAdjustPopup] = useState(false);
  const [adjustName, setAdjustName] = useState('');
  const [showRejectPopup, setShowRejectPopup] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  // 工单阶段性处理（协商节点）
  const [stepTemplate, setStepTemplate] = useState<StepTemplate[]>([]);
  const [responding, setResponding] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [showNegotiateStepPopup, setShowNegotiateStepPopup] = useState(false);
  const [negotiateStepId, setNegotiateStepId] = useState<number | null>(null);
  const [negotiateEndTime, setNegotiateEndTime] = useState<string | null>(null);
  const [negotiateReason, setNegotiateReason] = useState('');
  const [submittingNegotiate, setSubmittingNegotiate] = useState(false);
  // 未解决打回弹窗：提单人选择重新开始的阶段 + 节点结束时间
  const [showReopenPopup, setShowReopenPopup] = useState(false);
  const [reopenStepId, setReopenStepId] = useState<number | null>(null);
  const [reopenEndTime, setReopenEndTime] = useState<string | null>(null);
  const [submittingReopen, setSubmittingReopen] = useState(false);
  // 当前阶段完成弹窗：处理人选择下一阶段节点 + 节点结束时间
  const [showCompleteStepPopup, setShowCompleteStepPopup] = useState(false);
  const [completeNextStepId, setCompleteNextStepId] = useState<number | null>(null);
  const [completeNextEndTime, setCompleteNextEndTime] = useState<string | null>(null);
  const [submittingComplete, setSubmittingComplete] = useState(false);
  // 设置节点时间弹窗（已升级工单，处理人一锤定音）
  const [showSetStepTimePopup, setShowSetStepTimePopup] = useState(false);
  const [setStepTimeValue, setSetStepTimeValue] = useState<string | null>(null);
  const [submittingSetStepTime, setSubmittingSetStepTime] = useState(false);

  // 代他人提单（代理提单）关系：详情页顶部横幅数据源。
  // 后端对非参与人返回空数组（脱敏），故此处拿不到即视为无关系，无需前端再判权限。
  const [proxyRelation, setProxyRelation] = useState<ProxyRelation | null>(null);

  // 项目成员（用于讨论区 @ 提及）
  const [projectMembers, setProjectMembers] = useState<ProjectMember[]>([]);
  // 全部在职用户（项目成员 + 项目外，@ 输入过滤字时可 @ 到项目外的人）
  const [allUsers, setAllUsers] = useState<ProjectMember[]>([]);

  useEffect(() => {
    if (!detailId) { setDetail(null); return; }
    setDetailLoading(true);
    request<Ticket>(`/${detailId}?load_comments=true`, { skipCache: true })
      .then((t) => {
        setDetail(t);
        // 二次派单感知增强（M3）：未派到指定人时的完整话术
        setRedispatchTipDetail(t.redispatch?.result?.tip_detail || '');
        // 二次派单感知增强：派单理由（后端仅对接单人/管理员返回 reasoning，非空即展示）
        setDispatchReason(t.redispatch?.result?.reasoning || '');
        // 代理关系（代他人提单）：独立接口，失败不阻断详情渲染（横幅缺失而已）
        getProxyRelations(detailId)
          .then((list) => setProxyRelation(list?.[0] || null))
          .catch(() => setProxyRelation(null));
        // 摘要存 metadata_info.ai_summary（不混入讨论区）
        const meta = t.metadata_info || {};
        setAiSummary(typeof meta.ai_summary === 'string' ? meta.ai_summary as string : '');

        // 拉取协商阶段模板（按工单 task_type），用于「工单阶段性处理」当前节点描述
        request<{ code: number; data: { steps: StepTemplate[] } }>(`/${detailId}/steps`)
          .then((res) => setStepTemplate(res?.data?.steps || []))
          .catch(() => setStepTemplate([]));

        // 获取项目成员用于 @ 提及（无项目时也能拉到提单人和被指派人）
        getProjectMembers(detailId)
          .then((members) => {
            const reporterUsername = t.created_by;
            const sorted = [...members].sort((a, b) => {
              if (a.username === reporterUsername) return -1;
              if (b.username === reporterUsername) return 1;
              return 0;
            });
            setProjectMembers(sorted);
          })
          .catch(() => setProjectMembers([]));
        // 获取全部在职用户（@ 输入过滤字时扩展到项目外的人）
        getProjectMembers(detailId, true)
          .then((u) => setAllUsers(u))
          .catch(() => setAllUsers([]));
      })
      .catch((err) => Toast({ message: `详情加载失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' }))
      .finally(() => setDetailLoading(false));
  }, [detailId]);

  // 查看停留时长追踪：用户离开页面 / 切后台时回传累计可见秒数
  // 后端将累加到最近一条 VIEW 操作记录上（5 分钟去重窗口内同一条记录）
  useEffect(() => {
    if (!detailId) return;

    let accumulated = 0;                     // 累计可见秒数
    let lastActive: number | null = Date.now(); // 当前可见周期起始时间戳
    let sent = false;                        // 当前可见周期是否已回传

    const flush = () => {
      if (lastActive !== null) {
        accumulated += (Date.now() - lastActive) / 1000;
        lastActive = null;
      }
      const seconds = Math.floor(accumulated);
      if (seconds <= 0 || sent) return;
      sent = true;

      const token = getToken();
      if (!token) return;
      // keepalive 保证页面卸载时请求仍能发出
      fetch(`${API_CONFIG.TASKS.BASE_URL}/${detailId}/view-end`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ duration_seconds: seconds }),
        keepalive: true,
      }).catch(() => {});
    };

    const onVisibilityChange = () => {
      if (document.hidden) {
        // 切后台 / 最小化：立即回传当前可见周期时长
        flush();
      } else {
        // 恢复可见：开启新的可见周期（后端累加，不覆盖之前已回传的时长）
        lastActive = Date.now();
        accumulated = 0;
        sent = false;
      }
    };

    const onPageHide = () => flush();

    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('pagehide', onPageHide);

    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      window.removeEventListener('pagehide', onPageHide);
      // SPA 内部导航（组件卸载）：回传剩余时长
      flush();
    };
  }, [detailId]);

  // PC 微信专用：SPA(pushState) 跳转不会更新微信内部记录的「分享页 URL」，
  // 导致分享链接停留在首次加载的工单。检测当前工单是否经 SPA 跳入，是则用整页刷新修正。
  // 仅 PC 微信生效；手机端 / 普通浏览器走 SPA，不受影响。
  useEffect(() => {
    if (!detail?.id) return;
    if (!isPcWechat()) return;
    const current = window.location.href.split('#')[0];
    const nav = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined;
    const loadUrl = nav ? String(nav.name).split('#')[0] : '';
    if (loadUrl !== current) {
      window.location.href = current;
    }
  }, [detail?.id]);

  // 进入详情页即静默预置微信分享卡片：用户点右上角「…」可直接转发到群/好友/朋友圈，无需额外按钮
  useEffect(() => {
    if (!detail?.id) return;
    setupWechatShare({
      title: detail.title || '工单详情',
      desc: (detail.description || '').slice(0, 120) || `工单 #${detail.id}`,
      link: window.location.href,
      imgUrl: WECHAT_CONFIG.shareImgUrl,
    });
  }, [detail?.id]);

  const getCurrentUserRoles = () => {
    const currentName = name || username;

    const isAssignee = !!(
      isSameUser(detail?.assigned_to, userId, username) ||
      (detail?.assignee_name && (detail.assignee_name === username || detail.assignee_name === currentName)) ||
      (detail?.assigned_to_name && (detail.assigned_to_name === username || detail.assigned_to_name === currentName))
    );

    const isReporter = !!(
      isSameUser(detail?.created_by, userId, username) ||
      (detail?.reporter_name && (detail.reporter_name === username || detail.reporter_name === currentName)) ||
      (detail?.created_by_name && (detail.created_by_name === username || detail.created_by_name === currentName))
    );

    // 代他人提单（代理提单）视角：**优先后端下发的角色标记**，不倒推身份。
    // 后端已按 token 判定 is_agent / is_principal（见 ProxyRelationResponse），
    // 前端自拼判定会在「姓名重名 / username 与 id 混用」时判错（历史踩过的坑）。
    const isProxyAgent = proxyRelation?.is_agent ?? Boolean(detail?.is_proxy_agent);
    const isPrincipal = proxyRelation?.is_principal ?? Boolean(detail?.is_principal);

    return { isAssignee, isReporter, isProxyAgent, isPrincipal };
  };

  // 拥有 backend:tasks:operate 权限的用户可点击「创建人」设置其姓名
  const canEditCreatorName = !!detail && hasPermission('backend:tasks:operate');

  const getActionButtons = () => {
    const status = detail?.status?.toLowerCase();
    if (!status) return [];

    const isClosed = status === 'closed';
    const isCanceled = status === 'canceled' || status === 'cancelled';
    if (isClosed || isCanceled) return [];

    const { isAssignee, isReporter, isPrincipal } = getCurrentUserRoles();

    // 拥有 backend:tasks:operate 权限的用户，对所有活跃状态工单均可见且可操作
    const canOperate = hasPermission('backend:tasks:operate');

    const assigneeOnlyStatuses = ['new', 'in_progress', 'pending', 'paused'];
    if (assigneeOnlyStatuses.includes(status) && !isAssignee && !canOperate) return [];

    // 已解决：与后端口径统一（决策 6）—— 提单人(created_by，即代理人) / 已确认跟进的被代理人 / 管理员
    if (status === 'resolved' && !isReporter && !isPrincipal && !canOperate) return [];

    // 顶部操作按钮配色（设计稿 05：主推进 bg-primary 白字胶囊 / 次操作 bg-secondary 深字胶囊）
    const BTN_PRIMARY = { backgroundColor: 'var(--primary)', color: 'var(--primary-foreground)', borderRadius: '999px', border: 'none' };
    const BTN_SECONDARY = { backgroundColor: 'var(--secondary)', color: 'var(--foreground)', borderRadius: '999px', border: 'none' };
    const actions: Record<string, { label: string; nextStatus: string; theme: string; actionType?: string; customStyle?: Record<string, string> }[]> = {
      // new 状态由处理人首次响应（协商节点时间/确认同意）自动转为 in_progress，不再提供「开始处理」按钮
      new: [],
      in_progress: [
        { label: '暂停任务', nextStatus: 'pending', theme: 'warning', customStyle: BTN_SECONDARY },
        { label: '处理完成', nextStatus: 'resolved', theme: 'success', customStyle: BTN_PRIMARY },
      ],
      pending: (isAssignee && isReporter)
        ? [
            // 工单退回发起人后：发起人可重新发起（继续处理）或关闭工单
            { label: '重新发起', nextStatus: 'in_progress', theme: 'primary', actionType: 'resume', customStyle: BTN_PRIMARY },
            { label: '关闭工单', nextStatus: 'closed', theme: 'default', customStyle: BTN_SECONDARY },
          ]
        : [{ label: '继续处理', nextStatus: 'in_progress', theme: 'primary', actionType: 'resume', customStyle: BTN_PRIMARY }],
      resolved: [
        { label: '未解决', nextStatus: 'in_progress', theme: 'warning', actionType: 'reopen', customStyle: BTN_SECONDARY },
        { label: '确认关闭', nextStatus: 'closed', theme: 'default', customStyle: BTN_PRIMARY },
      ],
      canceled: [{ label: '重新打开', nextStatus: 'new', theme: 'primary', customStyle: BTN_PRIMARY }],
    };

    return actions[status] || [];
  };

  const handleStatusChange = async (action: { nextStatus: string }) => {
    if (!detail) return;
    // 清空前次阻塞提示
    setBlockedError(null);
    
    try {
      await request<Ticket>(`/${detail.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: action.nextStatus }),
      });
      refreshTasks();
      const statusLabel = STATUS_DISPLAY_MAP[action.nextStatus] || action.nextStatus;
      await refreshDetail();
      Toast({ message: `状态已更新为${statusLabel}`, theme: 'success' });
    } catch (err) {
      // 422 阻塞校验失败：提取 blocked 详情展示
      if (err instanceof ApiError && err.statusCode === 422) {
        const body = (err.errorBody as { detail?: BlockedErrorDetail })?.detail;
        if (body?.code === 'blocked_by_related_tasks') {
          setBlockedError(body);
          Toast({ message: `被 ${body.blocked.length} 个工单阻塞`, theme: 'error' });
          return;
        }
      }
      Toast({ message: `状态更新失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    }
  };

  const handleResume = async () => {
    if (!detail) return;
    
    try {
      await request<Ticket>(`/${detail.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'in_progress' }),
      });

      if (resumeUser) {
        await request(`/${detail.id}`, {
          method: 'PUT',
          body: JSON.stringify({ assigned_to: resumeUser.id || resumeUser.username, operation_type: 'reassign' }),
        });
      }

      const target = resumeUser?.name || resumeUser?.username || '原处理人';
      await refreshDetail();
      Toast({ message: `已继续处理，处理人${resumeUser ? `变更为 ${target}` : '保持不变'}`, theme: 'success' });
      setResumeUser(null);
      setShowResumePopup(false);
    } catch (err) {
      Toast({ message: `继续处理失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    }
  };

  const handleEscalate = async (t: Ticket) => {
    if (!escalateUser) {
      Toast({ message: '请先选择升级对象', theme: 'warning' });
      return;
    }
    if (!escalateReason.trim()) {
      Toast({ message: '请填写变更原因', theme: 'warning' });
      return;
    }
    const target = escalateUser.name || escalateUser.username;
    try {
      await request(`/${t.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          assigned_to: escalateUser.id || escalateUser.username,
          operation_type: 'escalate',
        }),
      });

      // 将升级原因记录为评论（系统评论只记录操作本身，不包含原因）
      try {
        await request(`/${t.id}/comments`, {
          method: 'POST',
          body: JSON.stringify({ content: `升级原因：${escalateReason.trim()}`, is_public: true }),
        });
      } catch {
        // 评论写入失败不阻断主流程，工单状态已变更
      }

      await refreshDetail();
      Toast({ message: `已升级，处理人已变更为 ${target}`, theme: 'success' });
      setEscalateUser(null);
      setEscalateReason('');
      setShowEscalatePopup(false);
    } catch (err) {
      Toast({ message: `升级失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    }
  };

  const getOperatorLabel = (): string => {
    return name || username || '当前用户';
  };

  // WS 工单状态变更（派单完成/改派/状态流转）实时更新详情，替代轮询
  const handleWsTaskUpdated = (patch: { status?: string; assigned_to?: string | null; assigned_to_name?: string | null; updated_at?: string | null }) => {
    setDetail((prev) => {
      if (!prev) return prev;
      // 用 updated_at 判断是否为过期推送（操作发起人自己已更新，跳过重复刷新）
      if (patch.updated_at && prev.updated_at) {
        const incoming = new Date(patch.updated_at).getTime();
        const current = new Date(prev.updated_at).getTime();
        if (incoming <= current) return prev;
      }
      // WS 推送的 assigned_to 可能为 null（退单/清空处理人），状态类型为 string | undefined，
      // null → undefined 以兼容类型，展示层有 || 兜底，null 与 undefined 表现一致。
      return {
        ...prev,
        ...(patch.status ? { status: patch.status } : {}),
        ...(patch.assigned_to !== undefined ? { assigned_to: patch.assigned_to ?? undefined } : {}),
        ...(patch.assigned_to_name !== undefined ? { assigned_to: patch.assigned_to_name ?? undefined } : {}),
      };
    });
    // WS 推送只含基础字段，阶段性处理等字段需拉全量刷新
    refreshDetail();
  };

  const refreshDetail = async () => {
    if (!detailId) return;
    const refreshed = await request<Ticket>(`/${detailId}?load_comments=true`, { skipCache: true });
    setDetail(refreshed);
    refreshTasks();
  };

  // 工单阶段性处理（协商节点）+ 结束工单（解决方式）：抽到共享 hook，与历史工单详情页复用
  const negotiation = useStepNegotiation(detailId ?? '', detail, refreshDetail);
  const resolve = useResolveTicket(detailId ?? '', detail, refreshDetail, refreshTasks, (b) => setBlockedError(b));

  // ===== 公司/部门审核 =====
  const approvalInfo = (() => {
    const meta = detail?.metadata_info || {};
    const approvalType = meta.approval_type as string | undefined;
    if (!approvalType) return null;
    return {
      type: approvalType as 'new_company' | 'new_department',
      targetTable: (meta.target_table as string) || '',
      targetId: (meta.target_id as string) || '',
      targetName: (meta.target_name as string) || '',
      companyName: meta.company_name as string | undefined,
    };
  })();

  const handleApprove = async () => {
    if (!approvalInfo) return;
    setApproving(true);
    try {
      const targetType = approvalInfo.type === 'new_company' ? 'company' : 'department';
      await adminRequest(`/users/options/${targetType}/${approvalInfo.targetId}/approve`, {
        method: 'PUT',
      });
      await request(`/${detail!.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'closed' }),
      });
      Toast({ message: '已审核通过', theme: 'success' });
      await refreshDetail();
    } catch (err) {
      Toast({ message: `审核失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    } finally {
      setApproving(false);
    }
  };

  // 调整名称后通过
  const handleAdjustApprove = async () => {
    if (!approvalInfo) return;
    const trimmed = (adjustName || '').trim();
    if (!trimmed) {
      Toast({ message: '请输入名称', theme: 'warning' });
      return;
    }
    setApproving(true);
    try {
      const targetType = approvalInfo.type === 'new_company' ? 'company' : 'department';
      await adminRequest(`/users/options/${targetType}/${approvalInfo.targetId}/approve`, {
        method: 'PUT',
        body: JSON.stringify({ new_name: trimmed }),
      });
      await request(`/${detail!.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'closed' }),
      });
      Toast({ message: '已调整名称并审核通过', theme: 'success' });
      setShowAdjustPopup(false);
      setAdjustName('');
      await refreshDetail();
    } catch (err) {
      Toast({ message: `操作失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    } finally {
      setApproving(false);
    }
  };

  const handleReject = async () => {
    if (!approvalInfo) return;
    if (!rejectReason.trim()) {
      Toast({ message: '请填写驳回原因', theme: 'warning' });
      return;
    }
    setApproving(true);
    try {
      const targetType = approvalInfo.type === 'new_company' ? 'company' : 'department';
      await adminRequest(`/users/options/${targetType}/${approvalInfo.targetId}/reject`, {
        method: 'PUT',
        body: JSON.stringify({ reason: rejectReason.trim() }),
      });
      await request(`/${detail!.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'closed' }),
      });
      Toast({ message: '已驳回', theme: 'success' });
      setShowRejectPopup(false);
      setRejectReason('');
      await refreshDetail();
    } catch (err) {
      Toast({ message: `驳回失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    } finally {
      setApproving(false);
    }
  };

  const handleReturn = async () => {
    if (!detail) return;
    if (!returnReason.trim()) {
      Toast({ message: '请填写变更原因', theme: 'warning' });
      return;
    }
    try {
      const returnTo = detail.created_by_name || detail.reporter_name || detail.created_by || '创建人';

      await request(`/${detail.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'pending' }),
      });

      if (detail.created_by) {
        await request(`/${detail.id}`, {
          method: 'PUT',
          body: JSON.stringify({ assigned_to: detail.created_by, operation_type: 'return' }),
        });
      }

      // 将退回原因记录为评论（系统评论只记录操作本身，不包含原因）
      try {
        await request(`/${detail.id}/comments`, {
          method: 'POST',
          body: JSON.stringify({ content: `退回原因：${returnReason.trim()}`, is_public: true }),
        });
      } catch {
        // 评论写入失败不阻断主流程，工单状态已变更
      }

      await refreshDetail();
      Toast({ message: `已退回工单，处理人变更为 ${returnTo}`, theme: 'success' });
      setReturnReason('');
      setShowReturnConfirmPopup(false);
    } catch (err) {
      Toast({ message: `退回失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    }
  };

  const handleReassign = async () => {
    if (!detail || !reassignUser) return;
    if (!reassignKind) {
      Toast({ message: '请选择转派类型', theme: 'warning' });
      return;
    }
    const target = reassignUser.name || reassignUser.username;
    const remark = reassignReason.trim();
    try {
      await request(`/${detail.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          assigned_to: reassignUser.id || reassignUser.username,
          operation_type: 'reassign',
          reassign_kind: reassignKind,
          reassign_reason: remark || undefined,
        }),
      });

      if (remark) {
        try {
          await request(`/${detail.id}/comments`, {
            method: 'POST',
            body: JSON.stringify({ content: `重新指派原因：${remark}`, is_public: true }),
          });
        } catch {
          // 评论写入失败不阻断主流程，工单状态已变更
        }
      }

      await refreshDetail();
      Toast({ message: `已重新指派给 ${target}`, theme: 'success' });
      setReassignUser(null);
      setReassignReason('');
      setReassignKind('');
      setShowReassignPopup(false);
    } catch (err) {
      Toast({ message: `重新指派失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    }
  };

  // 设置创建人姓名：通过工单 created_by 反查用户表更新 user.name（不改变 created_by）
  const handleUpdateCreatorName = async () => {
    if (!detail) return;
    const newName = creatorNameInput.trim();
    if (!newName) {
      Toast({ message: '姓名不能为空', theme: 'warning' });
      return;
    }
    setSubmittingCreatorName(true);
    try {
      await request(`/${detail.id}/creator-name`, {
        method: 'PATCH',
        body: JSON.stringify({ name: newName }),
        skipCache: true,
      });
      await refreshDetail();
      Toast({ message: '创建人姓名已更新', theme: 'success' });
      setShowCreatorNamePopup(false);
      setCreatorNameInput('');
    } catch (err) {
      Toast({ message: `更新失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    } finally {
      setSubmittingCreatorName(false);
    }
  };

  // 修改当前阶段截止时间：拥有 backend:tasks:operate 权限的用户直接改期（PUT /{id}）
  // deadlineDraft 为 undefined（用户未改动）时不提交 curr_step_endtime 字段，避免误清除
  const handleUpdateDeadline = async () => {
    if (!detail) return;
    setSubmittingDeadline(true);
    try {
      const body: Record<string, unknown> = { operation_type: 'update' };
      if (deadlineDraft !== undefined) body.curr_step_endtime = deadlineDraft;
      await request<Ticket>(`/${detail.id}`, {
        method: 'PUT',
        body: JSON.stringify(body),
        skipCache: true,
      });
      await refreshDetail();
      Toast({ message: '当前阶段截止时间已更新', theme: 'success' });
      setShowDeadlinePopup(false);
    } catch (err) {
      Toast({ message: `更新失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    } finally {
      setSubmittingDeadline(false);
    }
  };

  const [downloadingIdx, setDownloadingIdx] = useState<number | null>(null);
  const [viewer, setViewer] = useState<AttachmentViewItem | null>(null);

  const buildAttachmentDownloadUrl = (att: Attachment): string | null => {
    const rawPath = att.path || att.url || '';
    if (!rawPath) return null;
    let minioPath = rawPath;
    if (rawPath.startsWith('http://') || rawPath.startsWith('https://')) {
      const parsed = parseMinioPath(rawPath);
      if (!parsed) return null;
      minioPath = `${parsed.bucket}/${parsed.objectKey}`;
    }
    const authToken = readStored('AUTH_TOKEN') || '';
    // 必须拼成绝对 URL：微信内 window.open(相对URL) 打开的是微信内置 WebView，无法下载；
    // 用户「在浏览器打开」后相对路径在外部浏览器解析失败会落到 SPA 404 → 未登录重定向微信 OAuth
    // （表现为「提示跳转到微信客户端」）。绝对 URL 携带 token，在外部浏览器可直接下载。
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    return `${origin}${API_CONFIG.TASKS.BASE_URL}/attachments/download?path=${encodeURIComponent(minioPath)}&filename=${encodeURIComponent(att.filename || 'download')}&token=${encodeURIComponent(authToken)}`;
  };

  const handleAttachmentDownload = async (att: Attachment, idx: number) => {
    const downloadUrl = buildAttachmentDownloadUrl(att);
    if (!downloadUrl) { Toast({ message: '附件路径无效', theme: 'error' }); return; }

    setDownloadingIdx(idx);
    try {
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = att.filename || '';
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      Toast({ message: `下载失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    } finally {
      setDownloadingIdx(null);
    }
  };

  /** 构造附件内联预览 URL（/api/tasks/files/{minioPath}），供缩略图 <img> src 与 AttachmentViewer 共用 */
  const buildPreviewUrl = (att: Attachment): string | null => {
    const rawPath = att.path || att.url || '';
    if (!rawPath) return null;
    let minioPath = rawPath;
    if (rawPath.startsWith('http://') || rawPath.startsWith('https://')) {
      const parsed = parseMinioPath(rawPath);
      if (!parsed) return null;
      minioPath = `${parsed.bucket}/${parsed.objectKey}`;
    }
    return `${API_CONFIG.TASKS.BASE_URL}/files/${encodeURIComponent(minioPath)}`;
  };

  /** 打开附件预览（图片走灯箱、PDF/Markdown 内联渲染） */
  const openAttachmentViewer = (att: Attachment) => {
    const previewUrl = buildPreviewUrl(att);
    if (!previewUrl) { Toast({ message: '附件路径无效', theme: 'error' }); return; }
    setViewer({
      filename: att.filename || '未命名文件',
      size: att.size,
      previewUrl,
      downloadUrl: buildAttachmentDownloadUrl(att) || previewUrl,
    });
  };

  const startEdit = () => {
    if (!detail) return;
    setEditForm({
      title: detail.title,
      description: detail.description,
      priority: detail.priority || 'medium',
      ticket_type: detail.ticket_type || 'problem',
      curr_step_endtime: detail.curr_step_endtime || undefined,
    });
    setEditing(true);
  };

  const saveEdit = async () => {
    if (!detail) return;
    try {
      await request<Ticket>(`/${detail.id}`, {
        method: 'PUT',
        body: JSON.stringify({ ...editForm, operation_type: 'update' }),
      });
      await refreshDetail();
      Toast({ message: '修改成功', theme: 'success' });
      setEditing(false);
    } catch (err) {
      Toast({ message: `修改失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    }
  };

  // ── 当前阶段截止时间：编辑弹窗用 antd DatePicker 下拉选择（双端可用）──
  // 浮层 z-index 通过 styles.popup.root 提到高于 tdesign 编辑弹窗（z-index 11500），避免被遮挡



  const copyId = (id: string) => {
    navigator.clipboard?.writeText(id).then(() => Toast({ message: '已复制工单号', theme: 'success' }));
  };

  // ── 普通评论：POST /api/tasks/{id}/comments；返回 true=成功（组件清空输入） ──
  const handleAddComment = async (text: string, files: File[] = [], options?: { replyTo?: string | number }): Promise<boolean> => {
    if (!detail) {
      Toast({ message: '请输入评论内容', theme: 'warning' });
      return false;
    }
    setSubmittingComment(true);
    try {
      // 上传附件（同名文件自动改名，避免后端对象名重复覆盖）
      const tempId = generateTempId();
      const uploads = dedupeFileNames(files);
      for (const f of uploads) {
        await uploadCommentAttachment(f, tempId);
      }
      const newComment = await request<Comment>(`/${detail.id}/comments`, {
        method: 'POST',
        body: JSON.stringify({ content: text, is_public: true, attachments: files.length ? [tempId] : [], reply_to: options?.replyTo }),
      });
      const enrichedComment = {
        ...newComment,
        created_by_name: newComment.created_by_name || name || newComment.created_by || '未知用户',
        created_by: newComment.created_by || username,
      };
      setDetail((prev) => {
        if (!prev) return prev;
        const updatedComments = prev.comments ? [...prev.comments, enrichedComment] : [enrichedComment];
        return { ...prev, comments: updatedComments };
      });
      Toast({ message: files.length ? '评论和附件已添加' : '评论已添加', theme: 'success' });
      return true;
    } catch (err) {
      Toast({ message: `添加评论失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
      return false;
    } finally {
      setSubmittingComment(false);
    }
  };

  // 删除评论（后端按创建人鉴权）：成功后从本地列表移除
  const handleDeleteComment = async (id: string | number): Promise<void> => {
    if (!detail) return;
    await request(`/comments/${id}`, { method: 'DELETE' });
    setDetail((prev) => {
      if (!prev) return prev;
      return { ...prev, comments: (prev.comments || []).filter((c) => String(c.id) !== String(id)) };
    });
    Toast({ message: '评论已删除', theme: 'success' });
  };

  // ── @U老师 讨论：先存用户消息 → 调 POST /api/ai/task/discuss → 重新加载评论；返回 true=成功 ──
  const handleAIDiscuss = async (text: string, files: File[] = [], options?: { replyTo?: string | number }): Promise<boolean> => {
    if (!detail) return false;
    const userMsg = text;
    setAskingAI(true);
    try {
      // 上传附件（同名文件自动改名，避免后端对象名重复覆盖）
      const tempId = generateTempId();
      const uploads = dedupeFileNames(files);
      for (const f of uploads) {
        await uploadCommentAttachment(f, tempId);
      }
      // 1. 先保存用户的 @U老师 消息到 task_comments
      try {
        const newComment = await request<Comment>(`/${detail.id}/comments`, {
          method: 'POST',
          body: JSON.stringify({ content: userMsg, is_public: true, attachments: files.length ? [tempId] : [], reply_to: options?.replyTo }),
        });
        setDetail((prev) => {
          if (!prev) return prev;
          const updatedComments = prev.comments ? [...prev.comments, newComment] : [newComment];
          return { ...prev, comments: updatedComments };
        });
      } catch { /* 保存用户消息失败不阻塞 AI 调用 */ }
      // 2. 调 AI 讨论
      const recentComments = (detail.comments || []).slice(-10).map((c) => ({
        author: c.created_by_name || c.created_by || '?',
        content: c.content,
      }));
      const res = await fetchWithAuth(`${API_CONFIG.AI.BASE_URL}/task/discuss`, {
        method: 'POST',
        body: JSON.stringify({
          task_id: String(detail.id),
          // 去掉文本中任意位置的 @U老师 标记（可能有空格/重复），保留整段话作为 query，
          // 兼容"先说话、句尾@U老师"的场景（否则 @U老师 在尾部时 query 会带残留或丢失）
          query: userMsg.replace(/\s*@U老师\s*/g, ' ').trim(),
          context: { recent_comments: recentComments },
        }),
      });
      const data = await res.json();
      if (data.code === 0) {
        Toast({ message: 'AI 已回复', theme: 'success' });
        loadDetail();  // 重新加载评论（含 AI 回复）
        return true;
      } else {
        Toast({ message: data.message || 'AI 回复失败', theme: 'error' });
        return false;
      }
    } catch (err) {
      Toast({ message: `AI 回复失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
      return false;
    } finally {
      setAskingAI(false);
    }
  };

  // ── onSend：检测是否 @U老师（任意位置，前缀或句尾均触发）决定走普通评论还是 AI 讨论 ──
  const handleSendComment = async (text: string, files: File[], options?: { replyTo?: string | number }): Promise<boolean> => {
    // 只要文本里含 @U老师（@ 在开头/中间/结尾都算）就走 AI 讨论；
    // 兼容"说完话后句尾手动@U老师"（否则会被当成普通评论发出、AI 不回复）
    if (text.includes('@U老师')) {
      return handleAIDiscuss(text, files, options);
    }
    return handleAddComment(text, files, options);
  };

  // ── [帮我分析] → POST /api/ai/task/diagnose → 讨论区展示短链接 ──
  const handleDiagnose = async () => {
    if (!detail || diagnosing) return;
    setDiagnosing(true);
    try {
      const res = await fetchWithAuth(`${API_CONFIG.AI.BASE_URL}/task/diagnose`, {
        method: 'POST',
        body: JSON.stringify({ task_id: String(detail.id) }),
      });
      const data = await res.json();
      if (data.code === 0) {
        const d = data.data;
        // 原始 Markdown 存 state，供 Dialog 用 react-markdown 渲染
        setDiagnosisReport(d.report_md || d.root_cause_analysis || '');
        // 短链接预览取根因分析首行
        const preview = d.root_cause_analysis?.slice(0, 40) || '点击查看';
        const shortLink = `📋 [U老师 诊断报告 — ${preview}…](#diagnosis-report)`;
        setDetail((prev) => {
          if (!prev) return prev;
          const aiComment: Comment = {
            id: `diagnosis_${Date.now()}`,
            content: shortLink,
            created_by_name: AI_NAME,
            created_by: AI_NAME,
            created_at: new Date().toISOString(),
          };
          return { ...prev, comments: [...(prev.comments || []), aiComment] };
        });
      } else {
        Toast({ message: data.message || '分析失败', theme: 'error' });
      }
    } catch (err) {
      Toast({ message: `分析失败: ${err instanceof Error ? err.message : ''}`, theme: 'error' });
    } finally {
      setDiagnosing(false);
    }
  };

  // ── 点击诊断短链接 → 弹窗 ──
  const handleOpenReport = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    const link = target.closest('a');
    if (link && link.getAttribute('href') === '#diagnosis-report') {
      e.preventDefault();
      setReportVisible(true);
    }
  };

  // ── 重新加载（AI 讨论后刷新评论） ──
  const loadDetail = () => {
    if (!detailId) return;
    request<Ticket>(`/${detailId}?load_comments=true`, { skipCache: true })
      .then((t) => {
        setDetail(t);
        const meta = t.metadata_info || {};
        setAiSummary(typeof meta.ai_summary === 'string' ? meta.ai_summary as string : '');
        // 二次派单感知增强（M3）：未派到指定人时的完整话术（与「我要摇人」历史详情同口径）
        setRedispatchTipDetail(t.redispatch?.result?.tip_detail || '');
        // 二次派单感知增强：派单理由（后端仅对接单人/管理员返回 reasoning，非空即展示）
        setDispatchReason(t.redispatch?.result?.reasoning || '');
      })
      .catch(() => {});
  };

  // 派单完成 / 状态变更由 WS task.updated 实时推送（见 DiscussionPanel onTaskUpdated），不再轮询。

  // 返回任务列表，优先使用浏览器历史记录以保留筛选状态
  const handleBack = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/tasks');
    }
  };

  if (detailLoading) return <Loading text="加载中…" />;
  if (!detail) return (
    <div>
      <Navbar title="工单详情" fixed leftArrow onLeftClick={handleBack} />
      <div style={{ padding: 32, textAlign: 'center', color: 'var(--muted-foreground)', marginTop: 56 }}>工单不存在</div>
    </div>
  );

  const specDocRoles = getCurrentUserRoles();
  // 与后端 spec_doc._can_edit 口径一致：管理员 / 处理人 / 提单人 / 被代理人(已确认跟进)
  const canEditSpecDoc =
    isAdmin || specDocRoles.isAssignee || specDocRoles.isReporter || specDocRoles.isPrincipal;

  return (
    <div className="task-detail-page" style={{ paddingBottom: 72 }}>
      <Navbar
        title="工单详情"
        fixed
        leftArrow
        onLeftClick={handleBack}
      />
      <div className="page-container" style={{ paddingTop: 56 }}>
        <div className="detail-card">
          <div className="detail-card__header">
            <div className="detail-card__meta">
              {/* 状态胶囊（设计稿 statusText：bg-secondary + 蓝阶文字） */}
              <Tag
                data-testid="task-status"
                data-status={detail.status?.toLowerCase()}
                theme="default"
                style={{
                  background: 'var(--secondary)',
                  color: getStatusTextColor(detail.status),
                  border: 'none',
                  fontWeight: 600,
                  fontSize: 11.5,
                  borderRadius: 999,
                }}
              >
                {STATUS_DISPLAY_MAP[detail.status?.toLowerCase()] || detail.status}
              </Tag>
              {/* 类型胶囊（设计稿：bg-secondary muted） */}
              <Tag
                theme="default"
                style={{
                  background: 'var(--secondary)',
                  color: 'var(--muted-foreground)',
                  border: 'none',
                  fontWeight: 500,
                  fontSize: 11.5,
                  borderRadius: 999,
                }}
              >
                {TICKET_TYPE_DISPLAY_MAP[detail.ticket_type] || detail.ticket_type || '其他'}
              </Tag>
              <span className="detail-card__id" onClick={() => copyId(detail.id)}>#{detail.id}</span>
            </div>
            <div className="detail-card__action-btns">
              {getActionButtons().map((action, index) => (
                <Fragment key={index}>
                  {action.nextStatus === 'closed' && <span data-testid="task-close" hidden />}
                  {action.nextStatus === 'resolved' && <span data-testid="task-resolve" hidden />}
                  <AppButton
                    size="small"
                    theme={action.theme as 'primary' | 'default' | 'danger' | 'light'}
                    onClick={() => {
                      if (action.actionType === 'resume') {
                        setShowResumePopup(true);
                      } else if (action.actionType === 'reopen') {
                        // 未解决打回：选择重新开始的阶段 + 节点时间，阶段性处理从头开始
                        const firstStep = [...negotiation.stepTemplate].sort((a, b) => a.sequence - b.sequence)[0];
                        negotiation.setReopenStepId(firstStep ? firstStep.id : null);
                        negotiation.setReopenEndTime(null);
                        negotiation.setShowReopenPopup(true);
                      } else if (action.nextStatus === 'resolved') {
                        // 结束工单（→ resolved）→ 打开 "问题 + AI 解决方式" 确认弹窗
                        resolve.handleResolveClick();
                      } else {
                        handleStatusChange(action);
                      }
                    }}
                    className="detail-card__action-btn"
                    style={action.customStyle}
                  >
                    {action.label}
                  </AppButton>
                </Fragment>
              ))}
            </div>
          </div>
          {/* 代他人提单：关系横幅（代理人「你代 X 提交」/ 被代理人「X 代你提交」+ 确认跟进） */}
          {proxyRelation && (
            <ProxyRelationBanner
              ticketId={detail.id}
              relation={proxyRelation}
              onChanged={(updated) => {
                setProxyRelation(updated);
                // 关系变更影响可操作项（pending 只读 → acknowledged 获协办权），拉一次详情统一刷新
                loadDetail();
              }}
            />
          )}
          <h2 className="detail-card__title">
            <TitleEllipsis text={detail.title} lines={3} titleClassName="detail-card__title-inner" as="span" fontSize={19} lineHeight={1.3} />
          </h2>
          <div className="detail-card__info-grid">
            <div className="detail-info-item">
              <span className="detail-info-item__icon"><User size={14} strokeWidth={2} /></span>
              <div className="detail-info-item__content">
                <span className="detail-info-item__label">创建人</span>
                <span
                  className="detail-info-item__value"
                  style={canEditCreatorName ? { cursor: 'pointer', color: 'var(--blue-2)', textDecoration: 'underline' } : undefined}
                  onClick={canEditCreatorName ? () => {
                    setCreatorNameInput(detail.created_by_name || detail.reporter_name || detail.created_by || '');
                    setShowCreatorNamePopup(true);
                  } : undefined}
                >
                  {detail.created_by_name || detail.reporter_name || detail.created_by || '-'}
                </span>
              </div>
            </div>
            <div className="detail-info-item">
              <span className="detail-info-item__icon"><UserCheck size={14} strokeWidth={2} /></span>
              <div className="detail-info-item__content">
                <span className="detail-info-item__label">处理人</span>
                {/* AI 单派单中（status=new 且处理人未写入，Worker 60s 轮询派单）→ 呼吸动效「派单中」；
                    手动单未指派 → 「未指派」 */}
                {(() => {
                  const noAssignee = !detail.assignee_name && !detail.assigned_to_name && !detail.assigned_to;
                  const isAiTicket = !!detail.metadata_info?.session_id;
                  if (noAssignee && isAiTicket && detail.status === 'new') {
                    return (
                      <span data-testid="task-assignee" className="detail-info-item__value task-card2__person-name--dispatching">
                        <i className="dispatch-pulse dispatch-pulse--inline" />派单中
                      </span>
                    );
                  }
                  return (
                    <span data-testid="task-assignee" className="detail-info-item__value">
                      {detail.assignee_name || detail.assigned_to_name || detail.assigned_to || (noAssignee ? '未指派' : '-')}
                    </span>
                  );
                })()}
              </div>
            </div>
            <div className="detail-info-item">
              <span className="detail-info-item__icon"><Folder size={14} strokeWidth={2} /></span>
              <div className="detail-info-item__content">
                <span className="detail-info-item__label">所属项目</span>
                <span className="detail-info-item__value">{detail.project_name || '-'}</span>
              </div>
            </div>
            <div className="detail-info-item">
              <span className="detail-info-item__icon"><AlarmClock size={14} strokeWidth={2} /></span>
              <div className="detail-info-item__content">
                <span className="detail-info-item__label">当前阶段截止时间</span>
                <span className="detail-info-item__value">
                  {detail.deadline_at ? formatRawDateTime(detail.deadline_at) : '未设置'}
                </span>
              </div>
            </div>
            <div className="detail-info-item">
              <span className="detail-info-item__icon"><Clock size={14} strokeWidth={2} /></span>
              <div className="detail-info-item__content">
                <span className="detail-info-item__label">创建时间</span>
                <span className="detail-info-item__value">{formatDateTime(detail.created_at)}</span>
              </div>
            </div>
            <div className="detail-info-item">
              <span className="detail-info-item__icon"><RefreshCw size={14} strokeWidth={2} /></span>
              <div className="detail-info-item__content">
                <span className="detail-info-item__label">当前协商预期时间</span>
                <span className="detail-info-item__value">{detail.curr_step_endtime ? formatRawDateTime(detail.curr_step_endtime) : '—'}</span>
              </div>
            </div>
          </div>

          {/* 二次派单感知增强（M3）：未派到指定人时的完整话术（与「我要摇人」历史详情同口径） */}
          {redispatchTipDetail && (
            <DispatchFold label="派单提醒" text={redispatchTipDetail} variant="tip" />
          )}

          {/* 
              ┌──────────────┬─────────────┬───────────────────┬──────────────────┬──────────────┐
              │ 查看者/场景   │ dispatchReason│ redispatchTipDetail│ isAssignee/isAdmin│ 是否显示卡片  │
              ├──────────────┼─────────────┼───────────────────┼──────────────────┼──────────────┤
              │ 普通接单人   │ 空/有       │ 空(后端不返回 tip) │ isAssignee ✓      │ 仅看 reason │
              │ (有理由)     │（按后端给）  │                   │                  │   → 显示     │
              │ 接单人但无理由│ 空          │ 空                 │ isAssignee ✓      │  → 不显示    │
              │ 提单人==接   │ 空/有       │ 空                 │ isAssignee ✓      │  → 显示      │
              │ 单人(无 tip) │             │                   │                  │              │
              │ 提单人==接   │ 有          │ 有                 │ isAssignee ✓      │  → 不显示    │
              │ 单人(有 tip) │             │                   │                  │ (只显 tip)   │
              │ 管理员       │ 有          │ 依工单而定          │ isAdmin ✓         │ tip 空→显示  │
              │              │             │                   │                  │ tip 有→不显示│
              │ 其它第三方   │ 空(后端过滤)│ 空                 │ 均 ✗              │  → 不显示    │
              │ 老后端+第三方│ 有          │ —                 │ 均 ✗              │  → 不显示    │
              │ (前端兜底防泄│             │                   │                  │ (角色兜底拦) │
              │  露)         │             │                   │                  │              │
              └──────────────┴─────────────┴───────────────────┴──────────────────┴──────────────┘ */}
          {(() => {
            if (!dispatchReason || redispatchTipDetail) return null;
            const { isAssignee } = getCurrentUserRoles();
            if (!isAssignee && !isAdmin) return null;
            return (
              <DispatchFold label="派单原因" text={dispatchReason} variant="reason" />
            );
          })()}
        </div>

        <div className="detail-card">
          <h4 className="detail-card__h">问题描述</h4>
          <SafeHtml className="detail-card__body detail-card__body--pre" html={detail.description || '<p style="color:var(--muted-foreground)">无描述</p>'} />
        </div>

        {/* 问题文档：提单人结构化描述 + 接单人补充（md 在线编辑） */}
        <SpecDocCard taskId={detail.id} canEdit={canEditSpecDoc} />

        {/* 工单阶段性处理（协商节点）：抽到共享组件 StepNegotiationCard，与历史工单详情页复用 */}
        <StepNegotiationCard
          negotiation={negotiation}
          detail={detail}
          // 被代理人仅在已确认跟随后才参与协商（pending 只读，决策 10）
          roles={{
            ...getCurrentUserRoles(),
            isPrincipal: getCurrentUserRoles().isPrincipal && proxyRelation?.relation_status === 'acknowledged',
          }}
          onResolve={resolve.handleResolveClick}
          onEscalate={(round, maxRound) => {
            setEscalateUser(null);
            setEscalateReason(`已达最大协商回合（${round}/${maxRound}），申请升级介入处理。`);
            setShowEscalatePopup(true);
          }}
          onReassign={() => {
            setReassignUser(null);
            setReassignReason('');
            setShowReassignPopup(true);
          }}
        />

        {/* 公司/部门审核入口：仅管理员可见，工单 metadata_info 含 approval_type 时展示 */}
        {approvalInfo && username === 'admin' && (
          <div className="detail-card" style={{ border: '1.5px solid var(--blue-4)' }}>
            <h4 className="detail-card__h" style={{ color: 'var(--blue-2)', display: 'flex', alignItems: 'center', gap: 6 }}>
              {approvalInfo.type === 'new_company' ? <Building2 size={15} strokeWidth={2} /> : <Store size={15} strokeWidth={2} />}
              {approvalInfo.type === 'new_company' ? '新公司录入审核' : '新部门录入审核'}
            </h4>
            <div style={{ fontSize: 13, color: 'var(--foreground)', lineHeight: 1.8, marginBottom: 16 }}>
              <div>
                <strong>{approvalInfo.type === 'new_company' ? '公司名称' : '部门名称'}：</strong>
                {approvalInfo.targetName}
              </div>
              {approvalInfo.companyName && (
                <div><strong>所属公司：</strong>{approvalInfo.companyName}</div>
              )}
              <div style={{ fontSize: 12, color: 'var(--muted-foreground)', marginTop: 4 }}>
                请审核以下信息，通过后该{approvalInfo.type === 'new_company' ? '公司' : '部门'}将对所有用户可见
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <Button
                block
                theme="primary"
                loading={approving}
                onClick={handleApprove}
                style={{ borderRadius: '999px', backgroundColor: 'var(--blue-3)', color: '#fff', border: 'none' }}
              >
                通过
              </Button>
              <Button
                block
                theme="default"
                variant="outline"
                disabled={approving}
                onClick={() => { setAdjustName(approvalInfo.targetName); setShowAdjustPopup(true); }}
                style={{ borderRadius: '999px' }}
              >
                调整名称
              </Button>
              <Button
                block
                theme="danger"
                variant="outline"
                disabled={approving}
                onClick={() => setShowRejectPopup(true)}
                style={{ borderRadius: '999px' }}
              >
                驳回
              </Button>
            </div>
          </div>
        )}

        <TicketDynamicsCard taskId={detailId ?? ''} />

        {(() => {
          const meta = detail.metadata_info || {};
          const rs = typeof meta.resolution_summary === 'string' ? meta.resolution_summary as string : '';
          const isTerminal = ['resolved', 'closed'].includes((detail.status || '').toLowerCase());
          if (!isTerminal || !rs.trim()) return null;
          return (
            <div className="detail-card">
              <h4 className="detail-card__h">解决方式</h4>
              <div className="detail-card__body detail-card__body--pre">
                {rs}
              </div>
            </div>
          );
        })()}

        {/* 关联工单 */}
        {detail && (
          <RelationBlock
            taskId={Number(detail.id)}
            projectName={detail.project_name}
            projectId={detail.project_id}
            customer={detail.customer}
            canOperate={hasPermission('backend:tasks:operate')}
            blockedError={blockedError}
          />
        )}

        <div className="detail-card">
          <h4 className="detail-card__h">讨论摘要</h4>
          {aiSummary ? (
            <SafeHtml className="detail-card__body detail-card__body--pre" html={aiSummary} />
          ) : (
            <p className="detail-card__body detail-card__body--muted">暂无摘要，U老师 将自动总结讨论进展</p>
          )}
        </div>

        {detail.attachments && detail.attachments.length > 0 && (
          <div className="detail-card">
            <h4 className="detail-card__h">附件 ({detail.attachments.length})</h4>
            {(() => {
              const imgItems = detail.attachments.filter((a) => isImageFile(a.filename || ''));
              const fileItems = detail.attachments
                .map((a, i) => ({ att: a, origIdx: i }))
                .filter(({ att }) => !isImageFile(att.filename || ''));
              return (
                <>
                  {/* 图片缩略图网格：直接可见，点击放大（src 用代理 URL，避免 object_path 直链 404） */}
                  {imgItems.length > 0 && (
                    <div className="detail-attachment-thumbs">
                      {imgItems.map((att, i) => {
                        const thumbSrc = buildPreviewUrl(att);
                        if (!thumbSrc) return null;
                        return (
                          <img
                            key={`img-${i}`}
                            src={thumbSrc}
                            alt={att.filename || '图片'}
                            className="detail-attachment-thumb"
                            loading="lazy"
                            onClick={() => openAttachmentViewer(att)}
                            onError={(e) => {
                              // 微信 WebView 偶发 img 静默渲染失败（HTTP 200 但白屏）：破缓存重试一次，仍失败换文件名占位
                              const el = e.currentTarget;
                              if (!el.dataset.retried) {
                                el.dataset.retried = '1';
                                const sep = thumbSrc.includes('?') ? '&' : '?';
                                el.src = `${thumbSrc}${sep}_r=${Date.now()}`;
                              } else {
                                el.style.display = 'none';
                                const ph = document.createElement('div');
                                ph.className = 'detail-attachment-thumb detail-attachment-thumb--fallback';
                                ph.textContent = '🖼️';
                                ph.onclick = () => openAttachmentViewer(att);
                                el.parentNode?.appendChild(ph);
                              }
                            }}
                          />
                        );
                      })}
                    </div>
                  )}
                  {/* 非图片文件卡片（lucide 图标 + 文件名 + 下载，保留下载进度态） */}
                  {fileItems.length > 0 && (
                    <div className="detail-attachment-files">
                      {fileItems.map(({ att, origIdx }) => {
                        const filename = att.filename || '未命名文件';
                        const size = att.size ?? 0;
                        const sizeLabel = formatFileSize(size);
                        const isDownloading = downloadingIdx === origIdx;
                        return (
                          <div
                            key={`file-${origIdx}`}
                            role="button"
                            tabIndex={0}
                            className="detail-attachment-file"
                            style={{ opacity: isDownloading ? 0.6 : 1 }}
                            onClick={() => openAttachmentViewer(att)}
                            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') openAttachmentViewer(att); }}
                          >
                            <span className="detail-attachment-file__icon"><FileTypeIcon filename={filename} /></span>
                            <div className="detail-attachment-file__body">
                              <div className="detail-attachment-file__name">{filename}</div>
                              <div className="detail-attachment-file__size">{sizeLabel || '未知大小'}</div>
                            </div>
                            <span
                              role="button"
                              aria-label="下载附件"
                              title="下载"
                              className="detail-attachment-file__download"
                              onClick={(e) => { e.stopPropagation(); handleAttachmentDownload(att, origIdx); }}
                            >
                              {isDownloading ? <span className="detail-attachment-file__spinner" /> : <Download size={16} strokeWidth={2} />}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </>
              );
            })()}
          </div>
        )}

        <DiscussionPanel
          comments={detail.comments || []}
          onSend={handleSendComment}
          onDeleteComment={handleDeleteComment}
          sending={submittingComment || askingAI}
          optimisticAi={diagnosing || askingAI}
          enableAI
          enableAttach
          mentionUsers={projectMembers}
          mentionAllUsers={allUsers}
          taskId={detail?.id}
          onTaskUpdated={handleWsTaskUpdated}
          onMessagesClick={handleOpenReport}
          headerRight={
            <Button size="small" theme="primary" onClick={handleDiagnose} loading={diagnosing} icon={<Bot size={14} strokeWidth={2} />}>
              帮我分析
            </Button>
          }
          focusCommentId={focusDiscussion ? focusCommentId : null}
          focusAuthor={focusDiscussion ? focusAuthor : null}
        />

        {(() => {
          const status = detail.status?.toLowerCase();
          const isClosedOrCanceled = status === 'closed' || status === 'canceled' || status === 'cancelled';
          if (isClosedOrCanceled) return null;

          const { isAssignee, isReporter, isPrincipal } = getCurrentUserRoles();
          const canOperate = hasPermission('backend:tasks:operate');
          const assigneeOnlyStatuses = ['new', 'in_progress', 'pending', 'paused'];
          // 已解决：被代理人（已确认跟进）与提单人同权，可确认关闭（与后端 roles.can_close 对齐）
          const showRoleActions = canOperate || (assigneeOnlyStatuses.includes(status) ? isAssignee : (status === 'resolved' ? (isReporter || isPrincipal) : false));
          // 已解决状态：提单人仅可修改工单/升级上报，不应退回工单或重新指派
          // 退回工单/重新指派应由处理人在非已解决状态下操作
          const isResolved = status === 'resolved';
          // 达到最大回合：升级上报强制可见（提单人/接单人任一），替代管理员介入
          const round = detail.step_negotiation_round ?? 0;
          const maxRound = detail.step_neg_max_rounds ?? 3;
          const isEscalated = (detail.escalate_count ?? 0) > 0;
          const escalateCount = detail.escalate_count ?? 0;
          // 已升级上报后不再受回合上限限制
          const reachedMax = !isEscalated && round >= maxRound;
          const showEscalateAlone = reachedMax && (isAssignee || isReporter) && !showRoleActions;
          return (
            <div className="detail-actions">
              <div className="detail-actions__btns">
                {showRoleActions && (
                  <>
                    <Button size="small" theme="default" onClick={startEdit}>修改工单</Button>
                    {!isResolved && (
                      <Button size="small" theme="default" onClick={() => { setReturnReason(''); setShowReturnConfirmPopup(true); }}>退回工单</Button>
                    )}
                    {!isResolved && (
                      <Button size="small" theme="default" onClick={() => { setReassignUser(null); setReassignReason(''); setShowReassignPopup(true); }}>重新指派</Button>
                    )}
                    <Button
                      size="small"
                      theme={reachedMax ? 'danger' : 'default'}
                      onClick={() => {
                        setEscalateUser(null);
                        setEscalateReason(reachedMax ? `已达最大协商回合（${round}/${maxRound}），申请升级介入。` : '');
                        setShowEscalatePopup(true);
                      }}
                    >
                      {reachedMax ? '升级上报（回合超限）' : '升级上报'}
                    </Button>
                  </>
                )}
                {showEscalateAlone && (
                  <Button
                    size="small"
                    theme="danger"
                    onClick={() => {
                      setEscalateUser(null);
                      setEscalateReason(`已达最大协商回合（${round}/${maxRound}），申请升级介入。`);
                      setShowEscalatePopup(true);
                    }}
                  >
                    升级上报（回合超限）
                  </Button>
                )}
              </div>
            </div>
          );
        })()}
      </div>

      <Popup visible={editing} onClose={() => setEditing(false)} placement="bottom" showOverlay>
        <div className="ticket-edit-form">
          <div className="ticket-edit-form__header">
            <span className="ticket-edit-form__title">修改工单</span>
            <span className="ticket-edit-form__close" onClick={() => setEditing(false)}>×</span>
          </div>
          <div className="ticket-edit-form__body">
            <div className="ticket-edit-form__field">
              <label className="ticket-edit-form__label">标题</label>
              <ClearableInput
                value={editForm.title}
                onChange={(v) => setEditForm((p) => ({ ...p, title: String(v) }))}
                placeholder="请输入工单标题"
              />
            </div>
            <div className="ticket-edit-form__field">
              <label className="ticket-edit-form__label">问题描述</label>
              <Textarea
                value={editForm.description}
                onChange={(v) => setEditForm((p) => ({ ...p, description: String(v) }))}
                placeholder="请详细描述问题..."
                autosize={{ minRows: 5, maxRows: 12 }}
                maxlength={2000}
              />
            </div>
            <div className="ticket-edit-form__field">
              <label className="ticket-edit-form__label">优先级</label>
              <div className="tasks-create-modal__radio-group">
                {Object.entries(PRIORITY_DISPLAY_MAP).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    disabled={priorityDisabled}
                    title={priorityDisabled ? '仅待处理工单可修改优先级' : undefined}
                    aria-label={priorityDisabled ? `优先级${label}（仅待处理工单可修改优先级）` : `优先级${label}`}
                    className={`tasks-create-modal__radio-btn ${editForm.priority === value ? 'is-active' : ''} ${priorityDisabled ? 'is-disabled' : ''}`}
                    onClick={() => {
                      const r = getDeadlineRange(value, detail?.created_at);
                      setEditForm((p) => ({ ...p, priority: value, ...(r ? { curr_step_endtime: r.max.toISOString() } : {}) }));
                    }}
                  >{label}</button>
                ))}
              </div>
            </div>
            <div className="ticket-edit-form__field">
              <label className="ticket-edit-form__label">类型</label>
              <div className="tasks-create-modal__radio-group">
                {Object.entries(TICKET_TYPE_DISPLAY_MAP).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    className={`tasks-create-modal__radio-btn ${editForm.ticket_type === value ? 'is-active' : ''}`}
                    onClick={() => setEditForm((p) => ({ ...p, ticket_type: value }))}
                  >{label}</button>
                ))}
              </div>
            </div>
            {/* 当前阶段截止时间：antd DatePicker 下拉选择（双端可用），浮层 z-index 高于编辑弹窗避免被遮挡 */}
            <div className="ticket-edit-form__field">
              <label className="ticket-edit-form__label">当前阶段截止时间</label>
              <DatePicker
                style={{ width: '100%' }}
                placeholder="点击选择"
                format="YYYY-MM-DD HH:00"
                showTime={{ defaultValue: editDeadlineRange?.max ?? dayjs().hour(9).minute(0), format: 'HH:00', showNow: false }}
                showNow={false}
                placement="topLeft"
                getPopupContainer={(trigger) => trigger.parentElement || document.body}
                value={editForm.curr_step_endtime ? parseDeadlineString(editForm.curr_step_endtime) : null}
                disabledDate={editDeadlineRange ? makeDisabledDate(editDeadlineRange.min) : undefined}
                disabledTime={editDeadlineRange ? makeDisabledTime(editDeadlineRange.min) : undefined}
                onChange={(d: dayjs.Dayjs | null) =>
                  setEditForm((p) => ({
                    ...p,
                    curr_step_endtime: d ? d.minute(0).second(0).millisecond(0).toISOString() : undefined,
                  }))
                }
                allowClear
                styles={{ popup: { root: { zIndex: 12000 } } }}
              />
            </div>
          </div>
          <div className="ticket-edit-form__footer">
            <Button theme="default" block onClick={() => setEditing(false)}>取消</Button>
            <Button theme="primary" block onClick={saveEdit}>保存</Button>
          </div>
        </div>
      </Popup>

      <Popup visible={showEscalatePopup} onClose={() => { setShowEscalatePopup(false); setEscalateReason(''); }} placement="bottom" showOverlay destroyOnClose>
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">升级上报</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px' }}>请选择升级对象</p>
          <UserSelect value={escalateUser?.id ?? null} onChange={setEscalateUser} title="选择升级对象" />
          <Form initialData={{}}>
            <FormItem label="变更原因" name="escalateReason" labelAlign="top" requiredMark>
              <Textarea
                value={escalateReason}
                onChange={(v) => setEscalateReason(String(v))}
                placeholder="请输入升级原因（必填）"
                autosize={{ minRows: 3, maxRows: 6 }}
                maxlength={500}
              />
            </FormItem>
          </Form>
          <div className="ticket-edit__btns">
            <Button theme="default" onClick={() => { setShowEscalatePopup(false); setEscalateReason(''); }}>取消</Button>
            <Button theme="danger" onClick={() => handleEscalate(detail!)} disabled={!escalateUser || !escalateReason.trim()}>确认升级</Button>
          </div>
        </div>
      </Popup>

      <Popup visible={showResumePopup} onClose={() => { setShowResumePopup(false); setResumeUser(null); }} placement="bottom" showOverlay>
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">继续处理</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px' }}>选择新的受理人（可不选，直接确认则保持原处理人）</p>
          <UserSelect value={resumeUser?.id ?? null} onChange={setResumeUser} placeholder="请选择受理人（可选）" title="选择受理人" />
          <div className="ticket-edit__btns">
            <Button theme="default" onClick={() => { setShowResumePopup(false); setResumeUser(null); }}>取消</Button>
            <Button theme="primary" onClick={handleResume}>确认继续</Button>
          </div>
        </div>
      </Popup>

      {/* 结束工单确认弹窗：问题 + 工单解决方式（抽到 useResolveTicket） */}
      <Popup visible={resolve.showResolutionPopup} onClose={resolve.handleResolveCancel} placement="bottom" showOverlay>
        <div className="ticket-edit-form">
          <div className="ticket-edit-form__header">
            <span className="ticket-edit-form__title">确认完成工单</span>
            <span className="ticket-edit-form__close" onClick={resolve.handleResolveCancel}>×</span>
          </div>
          <div className="ticket-edit-form__body">
            {/* 工单问题 */}
            <div className="ticket-edit-form__field">
              <span className="ticket-edit-form__label">📌 工单问题</span>
              <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--foreground)', marginBottom: '4px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{detail?.title}</div>
              <div style={{
                fontSize: '13px', color: 'var(--muted-foreground)', lineHeight: 1.6, whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
              }}>
                {detail?.description || <span style={{ color: 'var(--gray-light)' }}>（无描述）</span>}
              </div>
            </div>

            {/* 工单解决方式 */}
            <div className="ticket-edit-form__field">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span className="ticket-edit-form__label" style={{ marginBottom: 0 }}>✅ 工单解决方式</span>
                {resolve.resolutionFailed && (
                  <span style={{ color: 'var(--apricot)', fontSize: '12px' }}>自动总结出错，请手动补充</span>
                )}
              </div>
              {resolve.resolutionLoading || resolve.resolutionPolling ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '20px 0', color: 'var(--muted-foreground)', fontSize: '13px', justifyContent: 'center' }}>
                  <Loading size="20px" /> 正在生成解决方式…
                </div>
              ) : (
                <Textarea
                  data-testid="task-resolution-summary"
                  value={resolve.resolutionText}
                  onChange={(v) => resolve.setResolutionText(String(v))}
                  placeholder={
                    resolve.resolutionNoSolution
                      ? '当前没有解决方案，请在此补充实际解决方式'
                      : resolve.resolutionFailed
                        ? 'U老师自动总结出错了，请补充解决方法'
                        : '请填写该工单的解决方式'
                  }
                  autosize={{ minRows: 4, maxRows: 8 }}
                  maxlength={1000}
                />
              )}
            </div>
          </div>
          <div className="ticket-edit-form__footer">
            <Button theme="default" onClick={resolve.handleResolveCancel}>取消</Button>
            <Button
              theme={resolve.resolutionFailed ? 'danger' : 'default'}
              onClick={resolve.resolutionFailed ? resolve.handleRetryResolution : resolve.handleGenerateResolution}
              loading={resolve.resolutionLoading || resolve.resolutionPolling}
              disabled={resolve.resolutionSubmitting || resolve.resolutionLoading || resolve.resolutionPolling}
            >
              {resolve.resolutionFailed ? '重试' : '帮我生成'}
            </Button>
            <>
              <span data-testid="task-resolve-confirm" hidden />
              <Button
                theme="primary"
                onClick={resolve.handleConfirmResolve}
                disabled={resolve.resolutionSubmitting || resolve.resolutionLoading || resolve.resolutionPolling || !resolve.resolutionText.trim()}
              >
                确认完成
              </Button>
            </>
          </div>
        </div>
      </Popup>


      <Popup visible={showReassignPopup} onClose={() => { setShowReassignPopup(false); setReassignUser(null); setReassignReason(''); setReassignKind(''); }} placement="bottom" showOverlay destroyOnClose>
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">重新指派</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px' }}>选择新的处理人</p>
          <UserSelect value={reassignUser?.id ?? null} onChange={setReassignUser} placeholder="请选择处理人" title="选择处理人" />
          <div style={{ margin: '12px 0 8px', fontSize: '14px', color: 'var(--foreground)' }}>转派类型<span style={{ color: 'var(--danger)' }}> *</span></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '12px' }}>
            {([
              { id: 'misassign' as const, label: '派错了', hint: '不该派给当前处理人，同类单会学习' },
              { id: 'stage' as const, label: '阶段转派', hint: '做到这个阶段该换人，不进入学习' },
              { id: 'other' as const, label: '其它', hint: '太忙、请假等，不进入学习' },
            ]).map((opt) => {
              const on = reassignKind === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setReassignKind(opt.id)}
                  style={{
                    textAlign: 'left',
                    padding: '10px 12px',
                    borderRadius: 'var(--radius-md)',
                    border: on ? '1px solid var(--primary)' : '1px solid var(--border)',
                    background: on ? 'var(--primary-soft)' : 'var(--card)',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--foreground)' }}>{opt.label}</div>
                  <div style={{ fontSize: '12px', color: 'var(--muted-foreground)', marginTop: '2px' }}>{opt.hint}</div>
                </button>
              );
            })}
          </div>
          <Form initialData={{}}>
            <FormItem label="变更原因" name="reassignReason" labelAlign="top">
              <Textarea
                value={reassignReason}
                onChange={(v) => setReassignReason(String(v))}
                placeholder="选填，补充说明（派错了时写上更有助于下次派准）"
                autosize={{ minRows: 3, maxRows: 6 }}
                maxlength={500}
              />
            </FormItem>
          </Form>
          <div className="ticket-edit__btns">
            <Button theme="default" onClick={() => { setShowReassignPopup(false); setReassignUser(null); setReassignReason(''); setReassignKind(''); }}>取消</Button>
            <Button theme="primary" onClick={handleReassign} disabled={!reassignUser || !reassignKind}>确认指派</Button>
          </div>
        </div>
      </Popup>

      <Popup
        visible={showCreatorNamePopup}
        onClose={() => { if (!submittingCreatorName) { setShowCreatorNamePopup(false); setCreatorNameInput(''); } }}
        placement="bottom"
        showOverlay
        destroyOnClose
      >
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">设置创建人姓名</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px', lineHeight: 1.6 }}>
            修改创建人（{(detail?.created_by_name || detail?.reporter_name || detail?.created_by || '-')}）的姓名，保存后工单创建人将显示新姓名。
          </p>
          <Form initialData={{}}>
            <FormItem label="姓名" name="creatorName" labelAlign="top" requiredMark>
              <ClearableInput
                value={creatorNameInput}
                onChange={(v) => setCreatorNameInput(String(v))}
                placeholder="请输入创建人姓名"
                maxlength={64}
              />
            </FormItem>
          </Form>
          <div className="ticket-edit__btns">
            <Button theme="default" disabled={submittingCreatorName} onClick={() => { setShowCreatorNamePopup(false); setCreatorNameInput(''); }}>取消</Button>
            <Button theme="primary" loading={submittingCreatorName} onClick={handleUpdateCreatorName} disabled={!creatorNameInput.trim()}>保存</Button>
          </div>
        </div>
      </Popup>

      <Popup
        visible={showDeadlinePopup}
        onClose={() => { if (!submittingDeadline) setShowDeadlinePopup(false); }}
        placement="bottom"
        showOverlay
        destroyOnClose
      >
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">修改当前阶段截止时间</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px', lineHeight: 1.6 }}>
            仅调整本工单的当前阶段截止时间，不影响其他字段；清空后表示不设置截止时间。
          </p>
          {(() => {
            // 选择下限 = 创建时间（取整到整点），不限制未来上限
            const range = getDeadlineRange(detail?.priority, detail?.created_at);
            return (
              <DatePicker
                style={{ width: '100%' }}
                placeholder="点击选择（可清空）"
                format="YYYY-MM-DD HH:00"
                showTime={{ defaultValue: dayjs().hour(9).minute(0), format: 'HH:00', showNow: false }}
                showNow={false}
                placement="topLeft"
                getPopupContainer={(trigger) => trigger.parentElement || document.body}
                value={deadlineDraft ? parseDeadlineString(deadlineDraft) : null}
                disabledDate={range ? makeDisabledDate(range.min) : undefined}
                disabledTime={range ? makeDisabledTime(range.min) : undefined}
                onChange={(d: dayjs.Dayjs | null) =>
                  setDeadlineDraft(d ? d.minute(0).second(0).millisecond(0).toISOString() : null)
                }
                allowClear
                styles={{ popup: { root: { zIndex: 12000 } } }}
              />
            );
          })()}
          <div className="ticket-edit__btns">
            <Button theme="default" disabled={submittingDeadline} onClick={() => setShowDeadlinePopup(false)}>取消</Button>
            <Button theme="primary" loading={submittingDeadline} onClick={handleUpdateDeadline}>保存</Button>
          </div>
        </div>
      </Popup>

      <Popup visible={showReturnConfirmPopup} onClose={() => { setShowReturnConfirmPopup(false); setReturnReason(''); }} placement="bottom" showOverlay destroyOnClose>
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">退回工单</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px', lineHeight: 1.6 }}>
            确定要将此工单退回吗？<br />
            退回后工单状态将变更为<span style={{ color: 'var(--apricot)', fontWeight: 500 }}>挂起</span>，处理人变更为创建人。
          </p>
          <Form initialData={{}}>
            <FormItem label="变更原因" name="returnReason" labelAlign="top" requiredMark>
              <Textarea
                value={returnReason}
                onChange={(v) => setReturnReason(String(v))}
                placeholder="请输入退回原因（必填）"
                autosize={{ minRows: 3, maxRows: 6 }}
                maxlength={500}
              />
            </FormItem>
          </Form>
          <div className="ticket-edit__btns">
            <Button theme="default" onClick={() => { setShowReturnConfirmPopup(false); setReturnReason(''); }}>取消</Button>
            <Button theme="danger" onClick={handleReturn} disabled={!returnReason.trim()}>确认退回</Button>
          </div>
        </div>
      </Popup>

      {/* 未解决打回弹窗：选择重新开始的阶段 + 节点结束时间，阶段性处理从头开始 */}
      <Popup
        visible={negotiation.showReopenPopup}
        onClose={() => { if (!negotiation.submittingReopen) negotiation.setShowReopenPopup(false); }}
        placement="bottom"
        showOverlay
        destroyOnClose
      >
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">标记未解决</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px', lineHeight: 1.6 }}>
            工单将打回到「处理中」，阶段性处理从头再开始：请选择重新开始的阶段及节点结束时间（SLA），打回后等待处理人确认。
          </p>
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 13, color: 'var(--muted-foreground)', marginBottom: 4 }}>
              重新开始的阶段<span style={{ color: 'var(--danger)' }}>*</span>
            </label>
            <select
              value={negotiation.reopenStepId ?? ''}
              onChange={(e) => negotiation.setReopenStepId(e.target.value ? Number(e.target.value) : null)}
              style={{
                width: '100%', padding: '8px 10px', fontSize: 14,
                border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)',
                background: 'var(--card)', color: 'var(--foreground)',
              }}
            >
              {[...negotiation.stepTemplate].sort((a, b) => a.sequence - b.sequence).map((s) => (
                <option key={s.id} value={s.id}>{`第${s.sequence + 1}步 · ${s.step_name}`}</option>
              ))}
            </select>
          </div>
          {(() => {
            // 选择下限 = 工单创建时间，与当前阶段截止时间编辑口径一致
            const range = getDeadlineRange(detail?.priority, detail?.created_at);
            return (
              <DatePicker
                style={{ width: '100%', marginBottom: 12 }}
                placeholder="点击选择节点结束时间"
                format="YYYY-MM-DD HH:mm"
                showTime={{ defaultValue: dayjs().hour(18).minute(0), format: 'HH:mm', showNow: false }}
                showNow={false}
                placement="topLeft"
                getPopupContainer={() => document.body}
                value={negotiation.reopenEndTime ? parseDeadlineString(negotiation.reopenEndTime) : null}
                disabledDate={range ? makeDisabledDate(range.min) : undefined}
                disabledTime={range ? makeDisabledTime(range.min) : undefined}
                onChange={(d: dayjs.Dayjs | null) =>
                  negotiation.setReopenEndTime(d ? d.second(0).millisecond(0).toISOString() : null)
                }
                allowClear
                styles={{ popup: { root: { zIndex: 13000 } } }}
              />
            );
          })()}
          <div className="ticket-edit__btns">
            <Button theme="default" disabled={negotiation.submittingReopen} onClick={() => negotiation.setShowReopenPopup(false)}>取消</Button>
            <Button theme="primary" loading={negotiation.submittingReopen} onClick={negotiation.handleReopenStep} disabled={!negotiation.reopenEndTime || !negotiation.reopenStepId}>确认打回</Button>
          </div>
        </div>
      </Popup>

      {/* 驳回原因弹窗 */}
      <Popup
        visible={showRejectPopup}
        onClose={() => { if (!approving) { setShowRejectPopup(false); setRejectReason(''); } }}
        placement="bottom"
        showOverlay
      >
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">驳回审核</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px', lineHeight: 1.6 }}>
            确定要驳回{approvalInfo?.type === 'new_company' ? '公司' : '部门'}「{approvalInfo?.targetName}」的录入申请吗？
          </p>
          <Form initialData={{}}>
            <FormItem label="驳回原因" name="rejectReason" labelAlign="top" requiredMark>
              <Textarea
                value={rejectReason}
                onChange={(v) => setRejectReason(String(v))}
                placeholder="请输入驳回原因（必填）"
                autosize={{ minRows: 3, maxRows: 6 }}
                maxlength={500}
              />
            </FormItem>
          </Form>
          <div className="ticket-edit__btns">
            <Button theme="default" disabled={approving} onClick={() => { setShowRejectPopup(false); setRejectReason(''); }}>取消</Button>
            <Button theme="danger" loading={approving} onClick={handleReject} disabled={!rejectReason.trim()}>确认驳回</Button>
          </div>
        </div>
      </Popup>

      {/* 调整名称弹窗 */}
      <Popup
        visible={showAdjustPopup}
        onClose={() => { if (!approving) { setShowAdjustPopup(false); setAdjustName(''); } }}
        placement="bottom"
        showOverlay
      >
        <div className="ticket-edit">
          <h4 className="ticket-edit__title">调整名称</h4>
          <p style={{ color: 'var(--muted-foreground)', fontSize: '13px', marginBottom: '12px', lineHeight: 1.6 }}>
            修改{approvalInfo?.type === 'new_company' ? '公司' : '部门'}名称后审核通过：
          </p>
          <Form initialData={{}}>
            <FormItem label="名称" name="adjustName" labelAlign="top" requiredMark>
              <ClearableInput
                value={adjustName}
                onChange={(v) => setAdjustName(String(v))}
                placeholder="请输入新的名称"
                maxlength={64}
              />
            </FormItem>
          </Form>
          <div className="ticket-edit__btns">
            <Button theme="default" disabled={approving} onClick={() => { setShowAdjustPopup(false); setAdjustName(''); }}>取消</Button>
            <Button theme="primary" loading={approving} onClick={handleAdjustApprove} disabled={!adjustName.trim()}>确认通过</Button>
          </div>
        </div>
      </Popup>

      <Dialog
        className="diagnosis-report-dialog"
        visible={reportVisible}
        title="U老师 诊断报告"
        confirmBtn="关闭"
        onConfirm={() => setReportVisible(false)}
      >
        <div className="markdown-body" style={{ maxHeight: '60vh', overflowY: 'auto', textAlign: 'left', fontSize: 14, lineHeight: 1.8 }}>
          {diagnosisReport ? (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              urlTransform={appUrlTransform}
            >
              {diagnosisReport}
            </ReactMarkdown>
          ) : (
            <p>暂无诊断数据</p>
          )}
        </div>
      </Dialog>

      {/* 附件预览：图片灯箱 / PDF 内联 / Markdown 渲染 */}
      <AttachmentViewer item={viewer} onClose={() => setViewer(null)} />
    </div>
  );
}
