/**
 * 会话历史 API —— /api/call/conversations + /messages
 *
 * 用途：把 AI 对话（ChatPanel）的每轮 user/assistant 消息持久化到 DB，
 * 刷新/切页后可按"当前用户 + 场景"恢复最近一条会话。
 *
 * 注意：user_id 由后端按 token 覆盖（前端只持有 username），故创建时传空串。
 */
import { createRequest } from '@/api/client';
import API_CONFIG from '@/config/api';

const request = createRequest(API_CONFIG.CALL.BASE_URL, '会话服务');

export type ChatScene = 'call' | 'tasks';

/** 前端场景 → 后端 SceneType 枚举（后端无 task_assist，tasks 映射为 consultation） */
const SCENE_TO_DB: Record<ChatScene, string> = { call: 'chat', tasks: 'consultation' };

export interface ConvMessage {
  id: number;
  role: 'user' | 'assistant' | 'system';
  content: string;
  created_at: string;
  /** JSON 字符串：附件列表 [{filename,url,size,isImage}]，恢复时解析重建图片/文件卡片 */
  file_urls?: string | null;
  message_type?: string;
}

export interface Conversation {
  id: number;
  title: string;
  user_id: string;
  scene_type: string;
  service_ticket_id: string;
  metadata_: string | null;
  created_at: string;
  updated_at: string;
  messages?: ConvMessage[];
}

/** 读取会话的 ai_session_id（恢复 AI 上下文用）。
 *  优先从 metadata_.ai_session_id 读；兜底 service_ticket_id（createConversation 已把 aiSessionId 写入）。 */
export function readAiSessionId(conv: { metadata_: string | null; service_ticket_id?: string | null }): string {
  if (conv.metadata_) {
    try {
      // 兼容后端 safe_json_dumps 对已 stringify 的 metadata_ 再次 dumps 导致的「双重 JSON 编码」：
      // parse 一次后若拿到的还是字符串，需再 parse 一次才能得到对象。后端根治前以此兜底。
      let obj = JSON.parse(conv.metadata_);
      if (typeof obj === 'string') obj = JSON.parse(obj);
      if (obj?.ai_session_id) return obj.ai_session_id;
    } catch { /* fallthrough 到 service_ticket_id 兜底 */ }
  }
  return conv.service_ticket_id || '';
}

/** 创建会话 */
export const createConversation = (params: { title: string; scene: ChatScene; aiSessionId?: string }) => {
  return request<Conversation>('/conversations', {
    method: 'POST',
    body: JSON.stringify({
      title: params.title,
      user_id: '', // 后端按 token 覆盖
      service_ticket_id: params.aiSessionId || '', // 纯聊天会话用 aiSessionId 占位，建立会话↔session 映射（rename_conversation 按此查）
      scene_type: SCENE_TO_DB[params.scene],
      metadata_: params.aiSessionId ? JSON.stringify({ ai_session_id: params.aiSessionId }) : null,
    }),
  });
};

/** 当前用户在指定场景下的会话列表（最新在前）；skipCache 确保删除/新建后列表是最新的 */
export const listMyConversations = (scene: ChatScene, limit = 5) =>
  request<Conversation[]>(`/conversations?scene_type=${SCENE_TO_DB[scene]}&limit=${limit}`, { skipCache: true });

/** 删除会话 */
export const deleteConversation = (id: number) =>
  request(`/conversations/${id}`, { method: 'DELETE' });

/** 更新会话标题 */
export const renameConversation = (id: number, title: string) =>
  request<Conversation>(`/conversations/${id}`, {
    method: 'PUT',
    body: JSON.stringify({ title }),
  });

/** 会话详情（含 messages） */
export const getConversation = (id: number) => request<Conversation>(`/conversations/${id}`);

/** 更新消息内容（PUT /messages/{id}）。
 *  用途：工单概览气泡派单状态回写——轮询查到 assigned_to 后，把 assigned_to_name 写进该消息 content JSON，
 *  实现派单状态持久化到 DB（切换/刷新后从 DB 读到即显示"已派单"，不依赖内存轮询跨切换存活）。 */
export const updateMessageContent = (messageId: number, content: string) =>
  request<ConvMessage>(`/messages/${messageId}`, {
    method: 'PUT',
    body: JSON.stringify({ content }),
  });

/** 追加一条消息（user/assistant）。
 *  options.fileUrls：JSON 字符串（附件列表），写入 DB messages.file_urls，刷新/切会话后可恢复图片/文件卡片。
 *  options.messageType：text(默认)/image/file，写入 DB messages.message_type（受后端 MessageType 枚举约束）。
 *  options.metadata：自由 JSON 字符串，写入 DB messages.metadata_（不受枚举约束），用于持久化自定义气泡标记
 *    （如工单概览：{kind:'ticket_overview'}）。注意 metadata 经后端 safe_json_dumps 会二次编码，恢复时需 parse 两次。 */
export const appendMessage = (
  conversationId: number,
  role: 'user' | 'assistant',
  content: string,
  options?: { fileUrls?: string; messageType?: string; metadata?: string },
) =>
  request<ConvMessage>('/messages', {
    method: 'POST',
    body: JSON.stringify({
      conversation_id: conversationId,
      role,
      content,
      message_type: options?.messageType ?? 'text',
      file_urls: options?.fileUrls ?? null,
      metadata_: options?.metadata ?? null,
    }),
  });
